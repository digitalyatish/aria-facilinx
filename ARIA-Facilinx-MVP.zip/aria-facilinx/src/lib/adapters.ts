import type {Incident,Message} from './domain';
export interface TelephonyAdapter{mode:'simulation'|'live';receive(id:string):Promise<{id:string;state:'connected'}>;end(id:string):Promise<void>}
export interface ConversationAdapter{mode:'scripted'|'provider';respond(messages:Message[]):Promise<Message>;transcribe?(audio:Blob):Promise<string>}
export interface NotificationAdapter{mode:'simulation'|'live';send(i:Incident,recipient:string,key:string):Promise<{providerId:string;status:'simulated_sent'|'sent'}>}
export interface CMMSAdapter{mode:'mock'|'live';prepare(i:Incident):Promise<{externalId:null;status:'prepared_only';payload:Record<string,unknown>}>}
export interface BuildingEventAdapter{mode:'mock'|'live';normalize(input:unknown):Promise<{asset:string;event:string;received:string}>}
export class MockFMXAdapter implements CMMSAdapter{mode='mock' as const;async prepare(i:Incident){return{externalId:null,status:'prepared_only' as const,payload:{source:'ARIA-DEMO',incident:i.id,summary:i.title,priority:i.priority,facility:i.facility,location:i.location,safety:i.reason}};}}
export const simulatorTelephony:TelephonyAdapter={mode:'simulation',async receive(id){return{id,state:'connected'};},async end(){}};
