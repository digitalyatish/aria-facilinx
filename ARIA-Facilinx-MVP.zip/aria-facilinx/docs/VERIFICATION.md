# Release verification — 6 November 2026

## Automated

23 Node acceptance/regression tests passed. TypeScript strict checking passed. Next.js static production build passed. See test-results.txt and build-results.txt.

Coverage includes P1/P2/P4 classification, unknown-safety escalation, partial intake persistence, same-timestamp audit order, concurrent duplicate-call idempotency, notification retries, escalation deadlines, acknowledgment/acceptance distinction, lifecycle transitions, schedule gaps, timezone validation, workflow validation, role restrictions, organization isolation, priority-override safeguards, configuration snapshots, PDF parsing, CSV injection protection, reset behavior and authenticated HTTP API/session/CSRF behavior.

## Browser walkthrough

Chrome, desktop preview:

- Water: answer call → safety response → P1 record and simulated notification → complete intake → acknowledgment → acceptance → en route → on site → resolve with handoff note. Passed.
- Incident PDF downloaded via the actual UI; parsed as two A4 pages, containing the resolution, full audit timeline and transcript. First page rendered and visually inspected. Passed.
- HVAC: safety response → P2 → Jamie Foster → simulated deadline advance → Drew Wilson backup → second advance → Casey Williams supervisor. No human response was falsely confirmed. Passed.
- Thermostat: safety response → P4 business-hours queue; notification panel confirmed no emergency notifications. Passed.
- Reload: three incidents persisted, with resolved/active counts and computed acknowledgment analytics intact. Passed.
- Workflow editor loaded its graph and accepted publication of the supported configuration. Analytics displayed dataset-derived metrics and all three records. Passed.

Screenshot evidence and sample incident PDF are included. This UI session uses synthetic test data; the deployed origin starts with a separate empty browser database.

## Deployment and verification boundaries

Private static Site deployment succeeded at https://aria-facilinx-response.yatishwar05.chatgpt.site . Owner sign-in may be required. Static hosting runs browser-local PostgreSQL WASM, not the optional shared server.

The HTTP API was tested against PostgreSQL-compatible PGlite; external PostgreSQL 17, Docker deployment, mobile-device rendering, live telephony, CMMS writes and Pelican event ingestion were not verified in this environment. Those integrations are not claimed operational. Server mode and container configuration are provided for subsequent deployment validation.
