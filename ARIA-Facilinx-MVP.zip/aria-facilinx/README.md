# ARIA by Facilinx

A working, no-key demonstration of accountable after-hours facilities response. Next.js, TypeScript, Tailwind, Framer Motion, React Flow, PostgreSQL/PGlite and pdf-lib.

## Run locally

Requires Node.js 24 and npm.

```sh
npm ci
npm run dev
```

Open the localhost address printed by Next.js. No API keys or credentials are required in browser demo mode. First load initializes PostgreSQL WASM and IndexedDB. Use one tab; records are local to that browser/origin and survive reload. Clearing browser data removes them. No background processing runs while the browser is closed.

## Five-minute demonstration

1. Command Center → Run Emergency Demo → Answer simulated call.
2. Answer the safety question. A P1 water/electrical incident is saved immediately, before caller details are finished. Notification is explicitly simulated.
3. Complete intake and open the incident. Review classification, transcript and event timeline.
4. Acknowledge, accept, mark en route and on site, then resolve with a note. These are separate human actions.
5. Download the incident PDF. Reload to verify persistence.
6. Repeat water intrusion and choose Simulate no response to advance the clock through backup and supervisor escalation.
7. Run HVAC failure (P2) and routine thermostat request (P4, queued without an emergency notification). An immediate-danger answer overrides ordinary routing.

The simulator uses deterministic, versioned rules and scripted conversation. Optional narration uses browser speech synthesis. It does not record audio, make phone calls, contact emergency services, dispatch technicians, or operate equipment.

## Checks and static build

```sh
npm run typecheck
npm test
npm run build
```

Serve `out/` using any static HTTPS host. The hosted Site uses this browser-local mode. Test and build results are in `docs/`.

## Shared server and PostgreSQL mode

The source includes a separate authenticated Express API, a PostgreSQL repository and a five-second escalation worker. The Next.js UI is statically exported with server mode selected at build time:

```sh
NEXT_PUBLIC_API_MODE=server npm run build
# Set DATABASE_URL, ADMIN_EMAIL and ADMIN_PASSWORD in your process environment.
# ADMIN_PASSWORD must contain at least 16 characters.
npm start
```

Copy `.env.example` as a reference; the shell/start command does not automatically load this file. Supply environment variables through your process manager or Docker. Use `COOKIE_SECURE=true` behind HTTPS; local HTTP requires false. Existing users are not reset by changing bootstrap environment variables.

Docker alternative: set POSTGRES_PASSWORD and ADMIN_PASSWORD in your environment, then `docker compose up --build`. The app listens on port 3000. PostgreSQL uses a named volume. Back up this volume using standard PostgreSQL tools. `SERVER_DB=pglite` is an explicit file-backed server demonstration alternative, not the shared PostgreSQL deployment.

## Scope and deployment limits

Ten screens cover command center, calls, incidents, workflow, agent configuration, facilities, on-call coverage, analytics, integrations and settings. Workflow editing preserves the supported safety/escalation graph; arbitrary executable graph changes are rejected. Scheduling supports explicit availability intervals, not recurrence or holiday rules. Analytics reflect stored demonstration events rather than promised business outcomes.

Telephony, FMX CMMS and Pelican interfaces are in `src/lib/adapters.ts`. FMX export is a prepared mock payload, not a submitted work order. No live integration is connected. Browser demo role switching is illustrative, not an authorization boundary. Server sessions enforce roles and organization scoping; only a bootstrap administrator is provisioned, with no user-management UI.

Before a live pilot: validate facility-specific safety and escalation policies with responsible personnel; implement real provider adapters and verified callbacks; add organization/user provisioning, durable distributed rate limiting, operational monitoring, backups, migration procedures and retention controls; test real PostgreSQL and container deployment in the target environment. This release is a functional demonstration, not an emergency-response service.

## Source guide

- `src/lib/domain.ts`: validated inputs, scenarios, policies, metrics.
- `src/lib/engine.ts`: transactional incident lifecycle, audit events, notification retries and escalation.
- `src/lib/client.ts`: browser PostgreSQL or authenticated HTTP transport.
- `src/lib/report.ts`: incident/management PDF and safe CSV exports.
- `src/components/App.tsx`: responsive interactive application.
- `server/`: SQL repository, sessions, permissions, API and worker.
- `tests/core.test.ts`: 23 acceptance/security/regression tests.

Database tables: organizations, configurations, config_history, incidents, events, notifications, app_users and sessions. Organization-scoped composite keys prevent cross-organization incident access. Configuration snapshots preserve an incident's original response policy. Database changes currently use idempotent bootstrap DDL; formal migrations are a pilot prerequisite.
