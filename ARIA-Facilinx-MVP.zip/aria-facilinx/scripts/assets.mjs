import {copyFileSync,mkdirSync} from 'node:fs';mkdirSync('public',{recursive:true});for(const f of ['pglite.wasm','pglite.data'])copyFileSync('node_modules/@electric-sql/pglite/dist/'+f,'public/'+f);
